from CTFd import create_app

app = create_app()
